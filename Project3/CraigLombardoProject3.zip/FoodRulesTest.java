import junit.framework.TestCase;

public class FoodRulesTest extends TestCase {
  
  public void testMakeMeal(){
    FoodRules test = new FoodRules();
  }
  
}