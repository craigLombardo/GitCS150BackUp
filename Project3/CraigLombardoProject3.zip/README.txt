To run this program you have to use the Optimizer class.
The arguments to pass in are as follows.
args[0] = recipeFile The recipe input file to read from.
args[1] = connectivityFile The connectivity input file to read from.
args[2] = farmFile The farm input file to read from.
args[3] = restFile The restaurant input file to read from.